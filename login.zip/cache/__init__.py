# Copyright (C) 2021 By VeezMusicProject

from cache.admins import admins, get, set

__all__ = ["admins", "get", "set"]
